 import os
import time
from selenium import webdriver
import  requests
import csv
import re
from random import randrange
from bs4 import BeautifulSoup
import random


dianping_home_url = "http://www.dianping.com/"
dianping_login_url = "http://account.dianping.com/login"
# 替换city和Index
#storepage_url = "http://www.dianping.com/city/ch10/pIndex"
storepage_url = "http://www.dianping.com/city/ch30/pIndex"

class Dianping:
    #用户保存读取的csv内容
    addressreader = {}
    shopnumreader = {}
    numreader = {}
    reviewreader = {}

    def __init__(self):
        print("Hello Dianping")
        self.shop_list = []

        self.proxyip = '49.71.159.96:4216'
        options = webdriver.ChromeOptions()  # 实例化设置菜单
        options.add_argument("–proxy-server=http://" + self.proxyip)  # 设置代理， =两边不能有空格
        self.browser = webdriver.Chrome(chrome_options=options)  # 实例化网页

    def __del__(self):
        print("Good Bye Dianping")
        self.browser.close()

    def Login(self):
        self.browser.get(dianping_login_url)
        print("请扫码登录")
        while True:
            time.sleep(1)
            flag = input("登录成功请按g,继续执行:")
            if flag == 'g' or flag == "G":
                break
        print("登录成功")

    def LoadData(self,city):
        txtpath="city/"+city+"/"+city+".txt"
        with open(txtpath, "r", encoding="utf-8", errors="ignnore") as f:
            self.shop_list = f.readlines()
##        print(self.shop_list)

    def GetStoreInfo(self, city):
        # try:
        for item in self.shop_list:
            print(item)
            url = item.replace("\n", "")
            # print("count:" + str(count) + "AAAurl:" + url)
            print("第二步成功")

            self.browser.get(url)
            time.sleep(3)
            self.browser.refresh()
            time.sleep(3)
            self.browser.refresh()
            time.sleep(3)
            self.browser.refresh()
            htmlname = url.replace(':', '=').replace('/', '_') + ".html"
            htmlpath = "city/" + city + "/" + "html/" + htmlname
            sleep = random.randint(1, 20) + 10
            time.sleep(sleep)

            # 写入文件
            with open(htmlpath, "a", encoding="utf-8", errors="ignnore") as f:
                f.write(self.browser.page_source)
                
        # except:
        #     print("EEEEEE")

if __name__ == '__main__':
    dianping = Dianping()
    dianping.Login()
    
    dianping.LoadData("beijing")
    dianping.GetStoreInfo("beijing")

    dianping.LoadData("shanghai")
    dianping.GetStoreInfo("shanghai")

    dianping.LoadData("shenzhen")
    dianping.GetStoreInfo("shenzhen")

    dianping.LoadData("chongqing")
    dianping.GetStoreInfo("chongqing")
    
    dianping.LoadData("guangzhou")
    dianping.GetStoreInfo("guangzhou")
    
    dianping.LoadData("suzhou")
    dianping.GetStoreInfo("suzhou")

    dianping.LoadData("chengdu")
    dianping.GetStoreInfo("chengdu")

    dianping.LoadData("hangzhou")
    dianping.GetStoreInfo("hangzhou")

    dianping.LoadData("nanjing")
    dianping.GetStoreInfo("nanjing")

    dianping.LoadData("wuhan")
    dianping.GetStoreInfo("wuhan")
