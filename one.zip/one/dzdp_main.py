import os
import time
from selenium import webdriver
import  requests
import csv
import re
from random import randrange
from bs4 import BeautifulSoup

class Dianping:
    #用户保存读取的csv内容
    addressreader2 = {}
    numreader = {}
    reviewreader = {}

    def __init__(self):
        print("Hello Dianping")
        self.LoadCsv()
        self.writeHead()

    def LoadCsv(self):
        with open("PingFangSC-Regular-address2.csv", encoding="UTF-8") as f:
            reader = csv.reader(f)
            for row in reader:
                self.addressreader2[row[1]] = row[0]

        with open("PingFangSC-Regular-num.csv", encoding="UTF-8") as f:
            reader = csv.reader(f)
            for row in reader:
                self.numreader[row[1]] = row[0]

        with open("PingFangSC-Regular-review.csv", encoding="UTF-8") as f:
            reader = csv.reader(f)
            for row in reader:
                self.reviewreader[row[1]] = row[0]

    def Convertaddress2HEX(self, hexstr):
        hexstr_true = ""
        for item in hexstr:
            # print("----")
            # print(item)
            # print('%#x' % ord(item))

            hex1 = '%#x' % ord(item)
            if hex1 == "0x20":
                continue
            if hex1[2:] in self.addressreader2.keys():
                #print(self.addressreader[hex1[2:]])
                hexstr_true = hexstr_true + self.addressreader2[hex1[2:]]
            else:
                hexstr_true = hexstr_true + item
        return  hexstr_true

    def ConvertnumHEX(self, hexstr):
        hexstr_true = ""
        for item in hexstr:
            hex1 = '%#x' % ord(item)
            if hex1 == "0x20":
                continue
            if hex1[2:] in self.numreader.keys():
                hexstr_true = hexstr_true + self.numreader[hex1[2:]]
            else:
                hexstr_true = hexstr_true + item
        return  hexstr_true
    
    def ConvertreviewHEX(self, hexstr):
        hexstr_true = ""
        for item in hexstr:
            hex1 = '%#x' % ord(item)
            if hex1 == "0x20":
                continue
            if hex1[2:] in self.reviewreader.keys():
                hexstr_true = hexstr_true + self.reviewreader[hex1[2:]]
            else:
                hexstr_true = hexstr_true + item
        return  hexstr_true   

    def WriteCSV(self,data_localhost,data_comment):
        csvpath1 ="data/" + city + '/localhost.csv'
        csvpath2 ="data/" + city + '/comment.csv'
        with open(csvpath1,'a+',encoding="gb18030", newline='') as f:
            writer = csv.writer(f)
            writer.writerow(data_localhost)
        with open(csvpath2,'a+',encoding="gb18030", newline='') as f:
            writer = csv.writer(f)
            writer.writerow(data_comment)

    def writeHead(self):
        csvpath1 = "data/" + city + '/localhost.csv'
        csvpath2 = "data/" + city + '/comment.csv'
        with open(csvpath1, 'a+', encoding="gb18030", newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['url']+['商铺名字']+['评分']+['评论数']+['单人消费']+['口味评分']+['环境评分']+['服务评分']+['商户电话']+['地址']+['订座']+['优惠（0/1）']+['榜单(仅手机端)']+['关键词']+['包含图片的评论数量']+['好评数量']+['中评数量']+['差评数量'])
        with open(csvpath2, 'a+', encoding="gb18030", newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['餐厅url']+['餐厅名称']+['评论者网名']+['等级']+['日期']+['打分']+['评论']+['推荐']+['商家是否回复（0/1）']+['点赞数']+['回复数']+['每个评论是否有照片（0/1）'])

    def GetStoreList(self,city):
        storelist = []
        # 将文件夹内所有的html文件名放在list中
        filepath ="data/"+city+"/html/"
        for filename in os.listdir(filepath):
            storelist.append(filename)
        return (storelist)

    def ParseStoreInfoBS(self,storelist):
        # 循环遍历list中的所有文件
        for item in storelist:
            htmlpath="data/"+city+"/"+"html/"+item
            try:
                bs = BeautifulSoup(open(htmlpath,encoding= "utf-8"),features= 'html.parser')
            except:
                continue

            #获取店铺名称
            text1=''
            text2=''
            if bs.find('h1', {'class': 'shop-name'}).find('a',{'class':'qr-contrainer'}):
                text1=self.Convertaddress2HEX(bs.find('h1', {'class': 'shop-name'}).find('a',{'class':'qr-contrainer'}).text) # 去除杂项
            if bs.find('h1', {'class': 'shop-name'}).find('a',{'class':'J-branch'}):
                text2=self.Convertaddress2HEX(bs.find('h1', {'class': 'shop-name'}).find('a',{'class':'J-branch'}).text) # 去除杂项
            title = self.Convertaddress2HEX(bs.find('h1', {'class': 'shop-name'}).text).replace(text1,'').replace(text2,'')
            # 获取店铺URL
            href=item.replace('=',':').replace('_','/')# 通过文件名获取
            #获取店铺评论数
            comment_count = self.ConvertnumHEX(bs.find('span', {'id': 'reviewCount'}).text)
            #获取人均价格
            mean_price = self.ConvertnumHEX(bs.find('span', {'id': 'avgPriceTitle'}).text)      
            #获取店铺地址
            address = self.Convertaddress2HEX(bs.find('span', {'id': 'address'}).text)        
            # 获取电话号码
            telinfo = self.ConvertnumHEX((bs.find('p', {'class': 'expand-info tel'}).text))
            #获取口味，环境，服务评分
            items=bs.find('span', {'id': 'comment_score'}).find_all('span',{'class','item'})
            for item in items:
                if ('口味' in self.ConvertnumHEX(item.text)):
                    tasty_score = self.ConvertnumHEX(item.text)
                if ("环境" in self.ConvertnumHEX(item.text)):
                    envir_score = self.ConvertnumHEX(item.text)
                if ("服务" in self.ConvertnumHEX(item.text)):
                    serv_score = self.ConvertnumHEX(item.text)
            
            #获取店铺评分
            #html中获取不到,只能算出来，不准！！！
            if (tasty_score[-4:-3]==':'):
                score = "4.5"
            else:
                sum1=float(tasty_score[-4:-1])+float(envir_score[-4:-1])+float(serv_score[-4:-1])
                score =str(round((sum1/3),2))

            # 获取有无优惠促销
            for item in bs.find_all('a',{'class':'item'}):
                if item.text=='优惠促销':
                    promotion=1
                    break
                else:
                    promotion=0
            # 获取提前订座信息
            if bs.find('a',{'id':'reservation'})==True:
                for item in bs.find_all('span',{'class':'hd'}):
                    if item.text == '提前订座':
                        reservation = bs.find('span', {'class': 'desc'}).text
            else:
                reservation = '无订座功能'
                
            if bs.find('div',{'class':'comment-filter-box'}):
                # 获取关键字
                keyword=''
                keywords = bs.find_all('a',{'data-click-title':'评价筛选标签'})
                for item in keywords:
                    keyword=keyword+','+item.text           
                keyword = keyword[1:]
                #获取图片评论数，好评数，中评数，差评数
                types = bs.find_all('label',{'class':'filter-item'})
                for item in types:
                    if item.text[0:2]=='图片':
                        cmt_count_pic = item.text[3:-1]
                    if item.text[0:2]=='好评':
                        cmt_count_good = item.text[3:-1]
                    if item.text[0:2]=='中评':
                        cmt_count_common = item.text[3:-1]
                    if item.text[0:2]=='差评':
                        cmt_count_bad = item.text[3:-1]
                #获取评论者网名
                try:
                    username=bs.find('p',{'class':'user-info'}).find('a',{'class':'name'}).text
                except:
                    username='none'
                #获取评论者等级
                try:
                    userlevel=bs.find('p',{'class':'user-info'}).find('img').get('src')[-7:-4]
                except:
                    userlevel='none'
                #获取评论日期
                date_raw=bs.find('span',{'class':'time'}).text.replace(' ','')
                date = date_raw[0:10]+date_raw[-18:]
                #获取客户打分
                userscore_raw=str(bs.find('span',{'class':'sml-rank-stars'}).get('class'))[-4:-2]
                userscore=userscore_raw[0]+'.'+userscore_raw[1]
                #获取客户评论
                userreview=self.ConvertreviewHEX(bs.find('p',{'class':'J-desc'}).text)
                #获取客户推荐菜
                userrec=bs.find('dd').text.replace('\n','、')[1:-1]
                #获取评论点赞数
                reviewagreenum=bs.find('a',{'class':'J-praise'}).text.replace('\n',',').replace(' ','').replace('"','').replace(',,','')
                if reviewagreenum=='赞':
                    reviewagreenum='赞(0)'
                #获取回复数
                reviewrespnum=bs.find('a',{'class':'J-response'}).text.replace('\n',',').replace(' ','').replace('"','').replace(',,','')
                if reviewrespnum=='回应':
                    reviewrespnum='回应(0)'
                #获取商家是否回复（0/1）
                if bs.find('a',{'class':'J-trigger'}):
                    if (bs.find('a',{'class':'J-trigger'}).text=='商家回应'):
                        businessresp='1'
                    else:
                        businessresp='0'
                else:
                    businessresp = '0'
                #获取每个评论是否有照片（0/1）
                if bs.find('a',{'class':'J-photo'}):
                    reviewphoto='1'
                else:
                    reviewphoto='0'
            else:
                continue
                
            # print("title:" + str(title))
            # print("href:" + str(href))
            # print("score:" + str(score))
            # print("comment_count:" + str(comment_count))
            # print("mean_price:" + str(mean_price))
            # print("tasty_score:" + str(tasty_score))
            # print("envir_score:" + str(envir_score))
            # print("serv_score:" + str(serv_score))
            # print("address:" + str(address))
            # print("telinfo:" + str(telinfo))
            # print("keywords:" + str(keyword))
            # print("cmt_count_pic:" + str(cmt_count_pic))
            # print("cmt_count_good:" + str(cmt_count_good))
            # print("cmt_count_common:" + str(cmt_count_common))
            # print("cmt_count_bad:" + str(cmt_count_bad))
            # print("promotion:" + str(promotion))
            # print("reservation:" + str(reservation))
            # print("username:" + str(username))
            # print("userlevel:" + str(userlevel))
            # print("date:" + str(date))
            # print("userscore:" + str(userscore))
            # print("userreview:" + str(userreview))
            # print("userrec:" + str(userrec))
            # print("reviewagreenum:" + str(reviewagreenum))
            # print("reviewrespnum:" + str(reviewrespnum))
            # print("businessresp:" + str(businessresp))
            # print("reviewphoto:" + str(reviewphoto))
            
            data_localhost= [str(href)]+[str(title)]+[str(score)]+[str(comment_count)]+[str(mean_price)]+[str(tasty_score)]+[str(envir_score)]+[str(serv_score)]+[str(telinfo)]+[str(address)]+[str(reservation)]+[str(promotion)]+["手机榜单预留"]+[str(keyword)]+[str(cmt_count_pic)]+[str(cmt_count_good)]+[str(cmt_count_common)]+[str(cmt_count_bad)]
            data_comment=[str(href)]+[str(title)]+[str(username)]+[str(userlevel)]+[str(date)]+[str(userscore)]+[str(userreview)]+[str(userrec)]+[str(businessresp)]+[str(reviewagreenum)]+[str(reviewrespnum)]+[str(reviewphoto)]

            self.WriteCSV(data_localhost, data_comment)  # 将数据写入csv文件

if __name__ == '__main__':
    city = "shanghai" # 修改需要的城市
    dianping = Dianping()
    storelist = dianping.GetStoreList(city)  # 从文件夹中获取html的名字list
    dianping.ParseStoreInfoBS(storelist)  # 访问解析每个html，得到数据并存储





