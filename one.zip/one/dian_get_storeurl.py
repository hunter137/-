import os
import time
from selenium import webdriver
import  requests
import csv
import re
from random import randrange
from bs4 import BeautifulSoup
import random
dianping_home_url = "http://www.dianping.com/"
dianping_login_url = "http://account.dianping.com/login"
# 替换city和Index
#storepage_url = "http://www.dianping.com/city/ch10/pIndex"
storepage_url = "http://www.dianping.com/city/ch30/pIndex"



class Dianping:
    #用户保存读取的csv内容
    addressreader = {}
    shopnumreader = {}
    numreader = {}
    reviewreader = {}

    def __init__(self):
        print("Hello Dianping")
        self.shop_list = []

        #self.proxyip = '123.163.21.59:4251'
        myoptions = webdriver.ChromeOptions()  # 实例化设置菜单
        #myoptions.add_argument(r'user-data-dir=C:\Users\WPS\AppData\Local\Google\Chrome\User Data')
        #myoptions.add_argument("–proxy-server=http://" + self.proxyip)  # 设置代理， =两边不能有空格
        self.browser = webdriver.Chrome(options=myoptions)  # 实例化网页

    def __del__(self):
        print("Good Bye Dianping")
        #self.browser.close()

    def Login(self):
        self.browser.get(dianping_login_url)
        print("请扫码登录")
        while True:
            time.sleep(1)
            flag = input("登录成功请按g,继续执行:")
            if flag == 'g' or flag == "G":
                break
        print("登录成功")

    def ChangeCity(self,city):
        city_url = dianping_home_url + city + "/"
        print("当前城市为：" + str(city_url))
        self.browser.get(city_url)

    def GetListOfStore(self, city, ch):
        store_list = []

        try:
            #获取店铺地址
            count = 0
            for page in range(50,60):
                page = page + 1
                page_url = dianping_home_url + city + "/" + ch + "/" + "p" + str(page)
                print("获取第" + str(page) + "页商店的地址：" + page_url)

                self.ParseStoreListPage(city, page_url)
        except:
            page_url = dianping_home_url + city + "/" + ch + "/" + "p" + str(page)
            print("page_url error :" + page_url )
        #访问单个商店
        # for url in self.shop_list:
        #     time.sleep(20)
        #     self.GetStoreInfo(url)

    def ParseStoreListPage(self, city,shoplisturl):
        self.browser.get(shoplisturl)
        sleep = random.randint(1, 20) + 10
        time.sleep(sleep)
        print("sleep" + str(sleep))
        for index in range(15):
            index = index + 1
            xpath = "/html/body/div[2]/div[3]/div[1]/div[1]/div[2]/ul/li[" + str(index) + "]/div[1]/a"
            href = self.browser.find_element_by_xpath(xpath).get_attribute("href")
            self.shop_list.append(href)
            print(href)

            with open(city+".txt", "a+", encoding="utf-8", errors="ignnore") as f:
                f.write(href + "\n")

    def GetStoreInfo(self, url):
        self.browser.get(url)
        htmlname=url.replace(':','_').replace('/','_')+".html"
        htmlpath="html/"+htmlname
        time.sleep(30)  # 保证浏览器响应成功后再进行下一步操作
        # 写入文件
        with open(htmlpath, "a", encoding="utf-8", errors="ignnore") as f:
            f.write(self.browser.page_source)

if __name__ == '__main__':
    dianping = Dianping()
    dianping.Login()
    #dianping.ChangeCity("shanghai")
    dianping.GetListOfStore("chengdu", "ch10")
    dianping.GetListOfStore("chongqing", "ch10")
    dianping.GetListOfStore("guangzhou", "ch10")

