使用步骤：
1.使用dian_get_storeurl.py，获取每个城市的500个店铺的url，并存进txt（路径：data/city/city.txt）
2.使用dian_get_storeInfo.py，逐个访问步骤1得到txt中每个店铺的url，并将源码存成html（路径：data/city/html/city/xxxx.html）
3.使用dzdp_main.py，解析步骤2中得到的html，将解析出来的信息存在comment.csv和localhost.csv中（路径：data/city/city/xxx.csv）

注意：运行dzdp_main.py时需要关闭.csv文件